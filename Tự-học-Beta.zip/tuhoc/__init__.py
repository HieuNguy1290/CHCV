"""TuHoc desktop app."""
