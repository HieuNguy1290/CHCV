# TuHoc Studio � K? ho?ch build canvas

## Ki?n tr�c

- Layout v2 luu pixel tr�n khung m�y t�nh 960�640 v� di?n tho?i 390�760. B? c?c di?n tho?i c� th? suy ra t? m�y t�nh r?i ch?nh ri�ng. M�y t�nh cu?n t?i da 2560 px. X�c minh gi?i h?n d?c c?a b?n di?n tho?i tru?c khi c? d?nh schema.
- D�ng chung h�nh h?c Pygame khi v? v� nh?n thao t�c. Editor dua Surface l�n Tkinter qua ImageTk r?i th�m lu?i, vi?n ch?n, tay n?m v� du?ng gi�ng. Ki?m tra Pillow v� c�ch d�ng g�i Windows.
- X�c minh registry d? 26 d?ng t? runtime. C�c nh�m g?m `free`, `container`, `token` v� `inline`. `option_N` l� v? tr� hi?n th? sau khi x�o. Preview t�i t?o th? t? ho?c ghi ch� th? t? ng?u nhi�n.

## P0 � Chu?n h?i quy

- [ ] Li?t k� m?i noi d?c layout. L?p ma tr?n 26 d?ng, du?ng ch?m, c�ch l?y `answer`, thao t�c v� noi ghi k?t qu?.
- [ ] Ch?y unit test d�ng, sai v� bi�n tr�n m� g?c. Thu `answer` t? runtime v� k?t qu? t? SQLite t?m.
- [ ] Sinh ?nh Pygame headless v� d? li?u hitbox v?i font, fixture v� th? t? phuong �n c? d?nh.
- [ ] Click t�m t?ng � tru?c v� sau cu?n. V?i d?ng cu chua cu?n du?c, l?y chu?n khi ph?n t? dang nh�n th?y. V?i d?ng n?i, x?p ho?c nh?p, ho�n t?t thao t�c d? thu `answer`.
- [ ] B�o c�o fixture m?u v� h?c li?u th?c t? c�n thi?u.

## P1 � S?a editor cu

- [ ] D�ng khung 960�640. S?a quy d?i t?a d? khi zoom, cu?n v� ki?m tra gi?i h?n `y + h`. Cho k�o xu?ng du?i `Y=640`.
- [ ] B? sung `input_area`, `dropdown_area`, `X/Y/W/H` v� nh�n phuong �n theo v? tr� hi?n th?.
- [ ] Ki?m tra luu, m? l?i v� thao t�c runtime. Sai s? h�nh h?c t?i da 1 px ? c�ng khung logic.

## P2 � Layout v2

- [ ] Th�m `layout_migrate.py`, `layout_render.py` v� `layout_templates.py`. �?c layout cu v� v2, gi? API c�ng khai v� �nh x? `input_area` n?u c?n.
- [ ] Ki?m tra round-trip tr�n `questions_addon.json`, `demo_exam_questions_grade1_family.json` v� b?n sao h?c li?u th?t.
- [ ] Migrate ch? thay v�ng byte c?a gi� tr? `layout`. T?o `.bak`, x�c minh `.tmp` tru?c `os.replace`, d?c l?i sau khi ghi, th? migrate l?p v� rollback.
- [ ] So ?nh editor v� runtime ? c�ng c?nh v� font. B? lu?i, vi?n ch?n v� tay n?m kh?i ph�p so. Sai kh�c t?i da 1% pixel. Ki?m tra hitbox ri�ng.

## P3 � TokenPicker v� d? r?ng

- [ ] T�ch h?p `picture_missing_letters`, `sentence_gaps`, `passage_gaps` v� `conversation_gaps`. T�ch ch? d? b? c?c kh?i ch? d? ch?n ch? ho?c t? ?n. Ki?m tra du?ng `collect()`.
- [ ] Cho `letter_items()` nh?n d? r?ng, k�ch thu?c � v� chi?u cao h�ng t? layout. Gi? th�ng s? g?c v?i c�u cu. Kh?i t? t? gi�n khi xu?ng d�ng. Ki?m tra `word_bank` v� c�u c� nhi?u lu?t tho?i.
- [ ] Cho `prompt` r?ng ri�ng v?i `picture_missing_letters`. R� m?i noi d?c `prompt` v� ki?m tra l?ch s?, �n c�u sai, k?t qu?. Gi? d? li?u r?ng v� d�ng nh�n d? ph�ng ? giao di?n.

## P4 � Studio ba c?t

- [ ] T�ch h?p danh s�ch l?p, metadata v� danh m?c b�n tr�i, canvas ? gi?a v� thu?c t�nh b�n ph?i trong tr�nh so?n hi?n t?i.
- [ ] Th�m ch?n m?u, kh�i ph?c m?c d?nh, ho�n t�c/l�m l?i, zoom, snap, t? cu?n, tr?ng th�i luu v� c?nh b�o khi d�ng b?n nh�p.
- [ ] M? preview Pygame v?i b?n chua luu. Ki?m tra chu?t, ph�m, � s?, th? t? Tab, tuong ph?n t?i thi?u 4,5:1 v� kh�ng ph�t sinh k?t qu?.

## P5 � Chuy?n runtime theo t?ng d?ng

- [ ] Th? d?u ti�n v?i `image_write_answer`. Th�m cu?n cho `image_sentence_extension.py` v� `listening_image_choice.py`. Th�m layout cho `image_letter_pick_extension.py`.
- [ ] Chuy?n t?ng d?ng c�n l?i. V?i m?i d?ng, ki?m tra c�u kh�ng layout, layout cu v� layout v2. �?i chi?u `answer` tru?c v� sau cu?n, ch?m di?m, x�o tr?n v� ghi k?t qu?.

## P6 � B�n giao

- [ ] Ch?y l?i to�n b? b? test. Ki?m tra t?ng d?ng b?ng GUI th?t tr�n Windows, g?m DPI, g� d?u, audio, resize, cu?n v� preview.
- [ ] Di?n t?p ph?c h?i `.bak` tr�n b?n sao. C?p nh?t `HUONG_DAN.txt`, danh s�ch file thay d?i, c�ch c�i ho?c ch�p d� v� checklist Windows.

## M?u b�o c�o phase

- **Phase v� tr?ng th�i** � �
- **Ph?m vi, file d? ki?n v� file d� d?i** � �
- **L?nh v� k?t qu? test tru?c/sau** � �
- **S? d?ng d� x�c minh** � � / 26
- **�?i chi?u ch?m, hitbox, `answer`, k?t qu? luu v� byte ngo�i layout** � �
- **B?ng ch?ng v� m?c chua x�c minh** � �
- **Quy?t d?nh chuy?n phase** � �