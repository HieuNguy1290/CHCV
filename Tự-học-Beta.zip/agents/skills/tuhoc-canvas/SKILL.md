---
name: tuhoc-canvas
description: Build, debug, and verify TuHoc Studio's Tkinter/Pygame question canvas, layout v2 migration, TokenPicker, preview, and exercise adapters. Use for TuHoc question layout, hitboxes, scrolling, or phases P0�P6.
---

# TuHoc Canvas

�?c [k? ho?ch P0�P6](references/build-plan.md). X�c minh m� ngu?n v� tr?ng th�i ki?m th? th?c t?. B?t d?u ? phase ngu?i d�ng y�u c?u ho?c phase s?m nh?t chua du?c x�c minh trong ph?m vi c�ng vi?c.

Tru?c m?i phase, n�u file d? ki?n s?a v� ch?y b? h?i quy P0. Sau m?i phase, ch?y l?i b? h?i quy v� b�o c�o file d� d?i, l?nh test, k?t qu? v� ph?n chua x�c minh. N?u m?t ki?m tra b?t bu?c th?t b?i, x? l� trong phase hi?n t?i r?i ch?y l?i. Khi ngu?i d�ng y�u c?u m?t phase duy nh?t, d?ng sau b�o c�o phase d�.

## Kh�a b?t bu?c

- Gi? nguy�n `exam_grading.is_correct`, m?i `is_correct` v� `normalize` trong `new_exercise_runtime.py` v� c�c `*_extension.py`, `Database.record()` v� schema `attempts`. X�c minh du?ng ghi th?c t? ? P0.
- Gi? nguy�n c�ch ch?m, x�o tr?n, luu k?t qu? v� validate hi?n c�, ngo?i tr? di?u ki?n d? r?ng du?c n�u b�n du?i.
- Khi ch?nh canvas ho?c migrate, gi? nguy�n `id`, `type`, `answer`, `options`, `distractors`, `pairs`, `sequence` v� `gap_answers`.
- L?p chu?n d�ng, sai v� bi�n cho c? 26 d?ng t? runtime g?c. Ph�t l?i thao t�c tru?c v� sau cu?n. So s�nh gi� tr?, ki?u v� th? t? c?a `answer`, k?t qu? ch?m v� b?n ghi th?c t?.
- Xem th? d�ng b?n nh�p, b? qua ch?m di?m v� t?o 0 lu?t n?p, 0 b?n ghi k?t qu?.
- Migrate ch? thay gi� tr? `layout` d� c�. Gi? t?ng byte b�n ngo�i c�c gi� tr? d�. D�ng copy-on-write, t?o `.bak`, x�c minh `.tmp`, r?i thay file b?ng `os.replace`. N?u ki?m tra sau thay file th?t b?i, ph?c h?i t? `.bak` v� x�c minh l?i.
- TokenPicker c?p nh?t `hidden_indices` qua `collect()` hi?n c� khi gi�o vi�n ch? d?ng ch?n ch? ho?c t? ?n v� luu. Thao t�c b? c?c gi? nguy�n gi� tr? n�y.
- Ch? cho ph�p `prompt` r?ng v?i `picture_missing_letters`. R� m?i noi d?c `prompt`, g?m l?ch s?, �n c�u sai v� k?t qu?. D�ng nh�n d? ph�ng ? ph?n hi?n th? khi c?n.
- Gi? c�ch hi?n th? cu cho c�u chua c� layout v� gi? c�c API c�ng khai dang du?c g?i. N�t Ho�n th�nh v� b? d?m c�u lu�n c? d?nh.
- D�ng Tkinter v� Pygame tr�n Windows, v?i giao di?n ti?ng Vi?t. B�o c�o k?t qu? GUI tr�n Windows ri�ng v?i k?t qu? headless. Ghi r� fixture n�o d�ng d? li?u m?u v� ph?n n�o c�n thi?u h?c li?u th?c t?.